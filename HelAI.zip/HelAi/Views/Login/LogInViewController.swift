//
//  LogInViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 01/09/23.
//

import UIKit
import Combine

class LogInViewController: UIViewController {
    
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var submitButton: UIButton!
    @IBOutlet var forgotButton: UIButton!
    @IBOutlet var warningLabel: UILabel!
    
    var observer: Set<AnyCancellable> = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
        configDependency()
        keyboardHandler()
    }
    
    private func configTheme() {
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background2")!)
        
        emailTextField.attributedPlaceholder = NSAttributedString(
            string: "Email",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.red]
        )
        passwordTextField.attributedPlaceholder = NSAttributedString(
            string: "Password",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.red]
        )
        
        passwordTextField.isSecureTextEntry = true
        
        submitButton.layer.borderWidth = 2
        submitButton.layer.borderColor = UIColor.systemRed.cgColor
        submitButton.layer.cornerRadius = submitButton.frame.height / 2
        
        forgotButton.layer.borderWidth = 2
        forgotButton.layer.borderColor = UIColor.white.cgColor
        forgotButton.layer.cornerRadius = forgotButton.frame.height / 2
        
        warningLabel.text = "Please enter correct email or password"
        warningLabel.isHidden = true
    }

    private func configDependency() {
        FirebaseHelper.shared.isLogedInObserver
            .sink(receiveValue: { value in
                if (value == self.emailTextField.text) {
                    let TbStoryboard = UIStoryboard(name: "TabBarScreen", bundle: .main)
                    let tabBarVC = TbStoryboard.instantiateViewController(withIdentifier: "TBController") as! TabBarViewController
                    tabBarVC.modalPresentationStyle = .fullScreen
                    self.present(tabBarVC, animated: true)
                } else {
                    self.showAccountAlert()
                }
            }).store(in: &observer)
    }
    
    private func showAccountAlert() {
        let alert = UIAlertController(
            title: "Failed !",
            message: "Not able to create account, try again",
            preferredStyle: .alert
        )
        self.present(alert, animated: true)
        DispatchQueue.main.asyncAfter(
            deadline: .now() + 1.5,
            execute: {
            alert.dismiss(animated: true)
        })
    }
    
    @IBAction func didTapSubmitButton(_ sender: UIButton) {
        if (passwordTextField.text?.isEmpty ?? true && emailTextField.text?.isEmpty ?? true) {
            showAccountAlert()
        } else {
            FirebaseHelper.shared.logIn(email: emailTextField.text!, password: passwordTextField.text!)
        }
    }
    
    @IBAction func didTapForgotButton(_ sender: UIButton) {
    }
    
    @IBAction func didTapBackButton(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
}

extension LogInViewController {

    private func keyboardHandler() {
        let tap = UITapGestureRecognizer(
            target: self,
            action: #selector(UIInputViewController.dismissKeyboard)
        )
        view.addGestureRecognizer(tap)

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillShow),
            name: UIResponder.keyboardWillShowNotification,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillHide),
            name: UIResponder.keyboardWillHideNotification,
            object: nil
        )
    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    @objc func keyboardWillShow(notification: NSNotification) {
        if ((notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey]
             as? NSValue)?.cgRectValue) != nil {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= 0
            }
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
}

