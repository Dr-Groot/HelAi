//
//  SignUpViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 01/09/23.
//

import UIKit
import Combine

class SignUpViewController: UIViewController {
    
    @IBOutlet var emailTextField: UITextField!
    @IBOutlet var passwordTextField: UITextField!
    @IBOutlet var signUpButton: UIButton!
    
    var observers: Set<AnyCancellable> = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
        configDependency()
        keyboardHandler()
    }
    
    private func configTheme() {
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background2")!)
        
        emailTextField.attributedPlaceholder = NSAttributedString(
            string: "Email",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.red]
        )
        passwordTextField.attributedPlaceholder = NSAttributedString(
            string: "Password",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.red]
        )
                
        passwordTextField.isSecureTextEntry = true
        
        signUpButton.layer.borderWidth = 2
        signUpButton.layer.borderColor = UIColor.systemRed.cgColor
        signUpButton.layer.cornerRadius = signUpButton.frame.height / 2
        
    }
    
    private func configDependency() {
        FirebaseHelper.shared.isAccountCreated
            .sink(receiveValue: { value in
                if value {
                    let TbStoryboard = UIStoryboard(name: "TabBarScreen", bundle: .main)
                    let tabBarVC = TbStoryboard.instantiateViewController(withIdentifier: "TBController") as! TabBarViewController
                    tabBarVC.modalPresentationStyle = .fullScreen
                    self.present(tabBarVC, animated: true)
                } else {
                    self.showAccountAlert()
                }
            }).store(in: &observers)
    }
    
    private func showAccountAlert() {
        let alert = UIAlertController(
            title: "Failed !",
            message: "Not able to create account, try again",
            preferredStyle: .alert
        )
        self.present(alert, animated: true)
        DispatchQueue.main.asyncAfter(
            deadline: .now() + 1.5,
            execute: {
            alert.dismiss(animated: true)
        })
    }
    
    @IBAction func didTapSignUpButton(_ sender: UIButton) {
        if emailTextField.text?.isEmpty ?? true, passwordTextField.text?.isEmpty ?? true {
            showAccountAlert()
        } else {
            FirebaseHelper.shared.accountCreate(email: emailTextField.text!, password: passwordTextField.text!)
        }
    }
    
    @IBAction func didTapBackButton(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
}

extension SignUpViewController {

    private func keyboardHandler() {
        let tap = UITapGestureRecognizer(
            target: self,
            action: #selector(UIInputViewController.dismissKeyboard)
        )
        view.addGestureRecognizer(tap)

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillShow),
            name: UIResponder.keyboardWillShowNotification,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillHide),
            name: UIResponder.keyboardWillHideNotification,
            object: nil
        )
    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    @objc func keyboardWillShow(notification: NSNotification) {
        if ((notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey]
             as? NSValue)?.cgRectValue) != nil {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= 0
            }
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
}
