//
//  CustomSplashViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 17/08/23.
//

import UIKit
import Lottie
import Firebase

class CustomSplashViewController: UIViewController {
    
    @IBOutlet var splashLottieView: LottieAnimationView!
    @IBOutlet var helLabel: UILabel!
    @IBOutlet var leftHelAILabelConstraint: NSLayoutConstraint!
    @IBOutlet var loadingLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configTheme()
        
        splashLottieAnimation()
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute: {
            self.animateHelAiText()
        })
    }
    
    private func configTheme() {
        loadingLabel.text = "Loading..."
        helLabel.text = "HELAI"
    }
    
    private func splashLottieAnimation() {
        splashLottieView.backgroundColor = .black
        splashLottieView.contentMode = .scaleAspectFill
        splashLottieView.loopMode = .loop
        splashLottieView.animationSpeed = 0.5
        splashLottieView.play()
    }
    
    private func animateHelAiText() {
        let animation: CATransition = CATransition()
        animation.timingFunction = CAMediaTimingFunction(name:
            CAMediaTimingFunctionName.easeInEaseOut)
        animation.type = CATransitionType.fade
        animation.subtype = CATransitionSubtype.fromTop
        self.leftHelAILabelConstraint.constant += 58
        self.helLabel.text = "AI"
        self.helLabel.textColor = .red
        animation.duration = 0.75
        self.helLabel.layer.add(animation, forKey: CATransitionType.fade.rawValue)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: {
            let animation2: CATransition = CATransition()
            animation2.timingFunction = CAMediaTimingFunction(name:
                CAMediaTimingFunctionName.easeInEaseOut)
            animation2.type = CATransitionType.push
            animation2.subtype = CATransitionSubtype.fromTop
            self.leftHelAILabelConstraint.constant -= 30
            self.helLabel.text = "AI"
            self.loadingLabel.text = "DONE"
            self.helLabel.textColor = .red
            animation2.duration = 0.5
            self.helLabel.layer.add(animation2, forKey: CATransitionType.fade.rawValue)
            self.loadingLabel.layer.add(animation2, forKey: CATransitionType.fade.rawValue)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
                self.moveToNextScreen()
            })
        })
    
    }
    
    private func moveToNextScreen() {
        
        if (FirebaseAuth.Auth.auth().currentUser != nil) {
            let TbStoryboard = UIStoryboard(name: "TabBarScreen", bundle: .main)
            let tabBarVC = TbStoryboard.instantiateViewController(withIdentifier: "TBController") as! TabBarViewController
            tabBarVC.modalPresentationStyle = .fullScreen
            self.navigationController?.present(tabBarVC, animated: true)
        } else {
            let LandingPageSB = UIStoryboard(name: "LandingPageScreen", bundle: .main)
            let landingPageVC = LandingPageSB.instantiateViewController(withIdentifier: "LandingPageVC") as! LandingPageViewController
            landingPageVC.modalPresentationStyle = .fullScreen
            self.present(landingPageVC, animated: true)
        }
    }
}
