//
//  ImageToTextViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 21/08/23.
//

import UIKit
import Combine
import AVFoundation

class ImageToTextViewController: UIViewController {
    
    @IBOutlet var selectImageButton: UIButton!
    
    @IBOutlet var textImage: UIImageView!
    @IBOutlet var dimensionLabel: UILabel!
    @IBOutlet var fileSizeLabel: UILabel!
    @IBOutlet var convertToTextButton: UIButton!
    @IBOutlet var imageToTextView: UITextView!
    @IBOutlet var playTextButton: UIButton!
    
    let viewModel = ImageToTextViewModel()
    var observers: Set<AnyCancellable> = []
    let synthesizer = AVSpeechSynthesizer()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
        configDependency()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.title = "IMAGE TO TEXT"
    }
    
    private func configTheme() {
        self.navigationItem.title = "IMAGE TO TEXT"
        
        selectImageButton.layer.borderWidth = 2
        selectImageButton.layer.borderColor = UIColor.white.cgColor
        selectImageButton.layer.cornerRadius = selectImageButton.frame.height / 2
        
        convertToTextButton.layer.borderWidth = 2
        convertToTextButton.layer.borderColor = UIColor.white.cgColor
        convertToTextButton.layer.cornerRadius = convertToTextButton.frame.height / 2
    
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "bin.xmark.fill")?.withTintColor(.systemRed, renderingMode: .alwaysOriginal),style: .plain, target: self, action: #selector(deleteImage))
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "chevron.backward")?.withTintColor(.white, renderingMode: .alwaysOriginal),style: .plain, target: self, action: #selector(dismissVC))
        
        textImage.image = UIImage(systemName: "icloud.slash.fill")?.withTintColor(.white, renderingMode: .alwaysOriginal)
        dimensionLabel.text = "0 * 0"
        fileSizeLabel.text = "0 KB"
        convertToTextButton.isHidden = true
        playTextButton.isHidden = true
    }
    
    private func configDependency() {
        let loadingSB = UIStoryboard(name: "LoadingScreen", bundle: .main)
        let loadingScreenVC = loadingSB.instantiateViewController(withIdentifier: "LoadingVC") as! LoadingViewController
        viewModel.imageToTextApiLoadingObeserver
            .sink(receiveValue: { value in
                if (value) {
                    print("LOADING")
                    loadingScreenVC.modalPresentationStyle = .overFullScreen
                    self.present(loadingScreenVC, animated: true)
                } else {
                    print("LOADED")
                    loadingScreenVC.popOver()
                    self.playTextButton.isHidden = false
                    self.playTextButton.setImage(UIImage(systemName: "play.fill"), for: .normal)
                }
            }).store(in: &observers)
        
        viewModel.imageToTextObserver
            .sink(receiveValue: { data in
                var convertedText = ""
                for val in data {
                    convertedText += (val.text ?? "") + " "
                }
                self.imageToTextView.text = convertedText
            }).store(in: &observers)
    }
    
    @objc private func deleteImage() {
        textImage.image = UIImage(systemName: "icloud.slash.fill")?.withTintColor(.white, renderingMode: .alwaysOriginal)
        dimensionLabel.text = "0 * 0"
        fileSizeLabel.text = "0 KB"
        convertToTextButton.isHidden = true
        imageToTextView.text = ""
        playTextButton.isHidden = true
    }
    
    @objc private func dismissVC() {
        self.navigationController?.popViewController(animated: true)
        self.synthesizer.pauseSpeaking(at: AVSpeechBoundary.immediate)
    }
    
    @IBAction func didTapSelectImageButton(_ sender: UIButton) {
        let imageSelectionAlertController = UIAlertController(title: "Select Image From", message: "Plase select options to fetch image", preferredStyle: .actionSheet)
        imageSelectionAlertController.addAction(
            UIAlertAction(
                title: "Select From Media",
                style: UIAlertAction.Style.default,
                handler: { _ in
                    let imagePickerVC = UIImagePickerController()
                    imagePickerVC.sourceType = .photoLibrary
                    imagePickerVC.delegate = self
                    imagePickerVC.allowsEditing = true
                    self.present(imagePickerVC, animated: true)
                }
            ))
        imageSelectionAlertController.addAction(
            UIAlertAction(
                title: "Select From Photo",
                style: UIAlertAction.Style.default,
                handler: { _ in
                    let cameraPickerVC = UIImagePickerController()
                    cameraPickerVC.sourceType = .camera
                    cameraPickerVC.allowsEditing = true
                    cameraPickerVC.delegate = self
                    self.present(cameraPickerVC, animated: true)
                }
            ))
        imageSelectionAlertController.addAction(
            UIAlertAction(
                title: "Cancel",
                style: UIAlertAction.Style.destructive
            ))
        self.present(imageSelectionAlertController, animated: true, completion: nil)
    }
    
    @IBAction func didTapConvertToTextButton(_ sender: UIButton) {
        viewModel.callImageToTextApi(image: textImage.image!)
    }
    
    @IBAction func didTapPlayTextButton(_ sender: UIButton) {
        self.playSound()
    }
    
}

extension ImageToTextViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerEditedImage")] as? UIImage {
            textImage.image = image
            dimensionLabel.text = "\(image.size.height) * \(image.size.width)"
            let imgData = NSData(data: image.jpegData(compressionQuality: 1)!)
            let imageSize: Int = imgData.count
            let imageSizeKB = Double(imageSize) / 1000.0
            fileSizeLabel.text = "\(round(imageSizeKB)) KB"
            convertToTextButton.isHidden = false
            imageToTextView.text = ""
            playTextButton.isHidden = true

            
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
}

extension ImageToTextViewController {
    private func playSound() {
        let textToPlayed = imageToTextView.text ?? ""
        self.playTextButton.setImage(UIImage(systemName: "pause.fill"), for: .normal)
        let utterance = AVSpeechUtterance(string: textToPlayed)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-GB")
        utterance.rate = 0.5
        synthesizer.speak(utterance)
        
        if synthesizer.isSpeaking {
            self.playTextButton.setImage(UIImage(systemName: "play.fill"), for: .normal)
            synthesizer.pauseSpeaking(at: AVSpeechBoundary.immediate)
        }
        if synthesizer.isPaused {
            self.playTextButton.setImage(UIImage(systemName: "pause.fill"), for: .normal)
            synthesizer.continueSpeaking()
        }
    }
}
