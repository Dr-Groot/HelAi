//
//  ImageToTextViewModel.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 22/08/23.
//

import Foundation
import Moya
import Combine

class ImageToTextViewModel {
    
    var observers: Set<AnyCancellable> = []
    var imageToTextObserver = PassthroughSubject<ImageToTextModelData, Never>()
    var imageToTextApiLoadingObeserver = PassthroughSubject<Bool, Never>()
    
    func callImageToTextApi(image: UIImage) {
        self.imageToTextApiLoadingObeserver.send(true)
        MoyaServiceProvider.homeService.requestPublisher(.imageToText(image: image))
            .sink(receiveCompletion: { Completion in
                switch Completion {
                case .finished:
                    print("Success: ImageToText API")
                case .failure(let error):
                    print("Error: \(error)")
                }
            }, receiveValue: {response in
                do {
                    let imageToTextData = try JSONDecoder().decode(ImageToTextModelData.self, from: response.data)
                    self.imageToTextObserver.send(imageToTextData)
                    self.imageToTextApiLoadingObeserver.send(false)
                } catch {
                    print("Error: Decoding Data ImageToText API")
                    self.imageToTextApiLoadingObeserver.send(false)
                }
            }).store(in: &observers)
    }
}
