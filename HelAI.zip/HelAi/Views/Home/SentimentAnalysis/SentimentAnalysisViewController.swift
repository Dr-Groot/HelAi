//
//  SentimentAnalysisViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 25/08/23.
//

import UIKit
import Combine

class SentimentAnalysisViewController: UIViewController {
    
    @IBOutlet var messageTextField: UITextField!
    @IBOutlet var searchButton: UIButton!
    @IBOutlet var clearButton: UIButton!
    @IBOutlet var scoreValueLabel: UILabel!
    @IBOutlet var analysisValueLabel: UILabel!
    @IBOutlet var textValueLabel: UILabel!
    
    
    private let viewModel = SentimentAnalysisViewModel()
    var observers: Set<AnyCancellable> = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configDependency()
        configTheme()
        keyboardHandler()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.title = "SENTIMENT ANALYSIS"
    }

    private func configTheme() {
        
        self.navigationItem.title = "SENTIMENT ANALYSIS"
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "chevron.backward")?.withTintColor(.white, renderingMode: .alwaysOriginal),style: .plain, target: self, action: #selector(dismissVC))
        
        messageTextField.layer.cornerRadius = messageTextField.frame.height / 2
        messageTextField.attributedPlaceholder = NSAttributedString(
            string: "Enter Text here ...",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
        
        defaultValues()
//        searchButton.layer.borderWidth = 2
//        searchButton.layer.borderColor = UIColor.systemRed.cgColor
//
//        clearButton.layer.borderWidth = 2
//        clearButton.layer.borderColor = UIColor.white.cgColor
    }
    
    private func defaultValues() {
        scoreValueLabel.text = "0.0"
        analysisValueLabel.text = "--"
        textValueLabel.text = "--"
    }
    
    private func configDependency() {
        let loadingSB = UIStoryboard(name: "LoadingScreen", bundle: .main)
        let loadingScreenVC = loadingSB.instantiateViewController(withIdentifier: "LoadingVC") as! LoadingViewController
        
        viewModel.sentimentAnalysisApiLoadingObserver
            .sink(receiveValue: {value in
                if (value) {
//                LOADING
                    loadingScreenVC.modalPresentationStyle = .overFullScreen
                    self.present(loadingScreenVC, animated: true)
                } else {
//                LOADED
                    loadingScreenVC.popOver()
                }
            }).store(in: &observers)
    
        viewModel.sentimentAnalysisData
            .sink(receiveValue: {value in
                self.setData(data: value)
            }).store(in: &observers)
    }
    
    private func setData(data: SentimentAnalysisData) {
        scoreValueLabel.text = "\(data.score ?? 0.0)"
        analysisValueLabel.text = data.sentiment
        textValueLabel.text = data.text
    }
    
    @objc private func dismissVC() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func didTapSearchButton(_ sender: UIButton) {
        dismissKeyboard()
        if (messageTextField.text == "") {
            let alert = UIAlertController(title: "No text found", message: "Please enter text to get your analysis report", preferredStyle: .alert)
            self.present(alert, animated: true)
            DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: {
                alert.dismiss(animated: true)
            })
        } else {
            viewModel.callSentimentAnalysisApi(text: messageTextField.text ?? "")
            defaultValues()
        }
    }
    
    @IBAction func didTapClearButton(_ sender: UIButton) {
        defaultValues()
        messageTextField.text = ""
        dismissKeyboard()
    }
    
}

extension SentimentAnalysisViewController {

    private func keyboardHandler() {
        let tap = UITapGestureRecognizer(
            target: self,
            action: #selector(UIInputViewController.dismissKeyboard)
        )
        view.addGestureRecognizer(tap)

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillShow),
            name: UIResponder.keyboardWillShowNotification,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillHide),
            name: UIResponder.keyboardWillHideNotification,
            object: nil
        )
    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    @objc func keyboardWillShow(notification: NSNotification) {
        if ((notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey]
             as? NSValue)?.cgRectValue) != nil {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= 0
            }
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
}
