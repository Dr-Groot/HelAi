//
//  SentimentAnalysisViewModel.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 25/08/23.
//

import Foundation
import Combine

class SentimentAnalysisViewModel {
    
    var observers: Set<AnyCancellable> = []
    var sentimentAnalysisData = PassthroughSubject<SentimentAnalysisData, Never>()
    var sentimentAnalysisApiLoadingObserver = PassthroughSubject<Bool, Never>()
    
    func callSentimentAnalysisApi(text: String) {
        self.sentimentAnalysisApiLoadingObserver.send(true)
        MoyaServiceProvider.homeService.requestPublisher(.sentimentAnalysis(text: text))
            .sink(receiveCompletion: { Completion in
                switch Completion {
                case .finished:
                    print("Success: SENTIMENT ANALYSIS Api called")
                case .failure(let error):
                    print("Error: \(error)")
                }
            }, receiveValue: {response in
                do {
                    let sentimentData = try JSONDecoder().decode(SentimentAnalysisData.self, from: response.data)
                    self.sentimentAnalysisData.send(sentimentData)
                    self.sentimentAnalysisApiLoadingObserver.send(false)
                } catch {
                    print("Error Decoding Sentiment Analysis Response")
                    self.sentimentAnalysisApiLoadingObserver.send(false)
                }
            }).store(in: &observers)
    }
    
}
