//
//  ObjectDetectionViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 23/08/23.
//

import UIKit
import Combine

class ObjectDetectionViewController: UIViewController {

    @IBOutlet var selectImageButton: UIButton!
    @IBOutlet var objectDetectionImageView: UIImageView!
    @IBOutlet var sizeValueLabel: UILabel!
    @IBOutlet var checkButton: UIButton!
    @IBOutlet var mainTableView: UITableView!
    
    var observers: Set<AnyCancellable> = []
    private let viewModel = ObjectDetectionViewModel()
    var objectDetectionData: ObjectDetectionData = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
        configDependency()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.title = "OBJECT DETECTION"
    }
    
    private func configTheme() {
        self.navigationItem.title = "OBJECT DETECTION"
        
        objectDetectionImageView.image = UIImage(systemName: "externaldrive.badge.xmark")?.withRenderingMode(.alwaysOriginal)
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "chevron.backward")?.withTintColor(.white, renderingMode: .alwaysOriginal),style: .plain, target: self, action: #selector(dismissVC))
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "bin.xmark.fill")?.withTintColor(.systemRed, renderingMode: .alwaysOriginal),style: .plain, target: self, action: #selector(deleteImage))
        
        selectImageButton.layer.borderWidth = 2
        selectImageButton.layer.borderColor = UIColor.white.cgColor
        selectImageButton.layer.cornerRadius = selectImageButton.frame.height / 2
        
        checkButton.layer.borderWidth = 2
        checkButton.layer.borderColor = UIColor.white.cgColor
        checkButton.layer.cornerRadius = checkButton.frame.height / 2
        
        checkButton.isHidden = true
        sizeValueLabel.text = "0 KB"
        
        mainTableView.register(cellType: ObjectDetectionTableViewCell.self)
        mainTableView.dataSource = self
        mainTableView.delegate = self
    }
    
    private func configDependency() {
        let loadingSB = UIStoryboard(name: "LoadingScreen", bundle: .main)
        let loadingScreenVC = loadingSB.instantiateViewController(withIdentifier: "LoadingVC") as! LoadingViewController
        
        viewModel.objectDetectionApiLoadingObserver
            .sink(receiveValue: {value in
                if (value) {
//                LOADING
                    loadingScreenVC.modalPresentationStyle = .overFullScreen
                    self.present(loadingScreenVC, animated: true)
                } else {
//                LOADED
                    loadingScreenVC.popOver()
                }
            }).store(in: &observers)
    
        viewModel.objectDetectionObserver
            .receive(on: DispatchQueue.main)
            .sink(receiveValue: {value in
                self.objectDetectionData = value
                self.mainTableView.reloadData()
            }).store(in: &observers)
    }
    
    @objc private func dismissVC() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc private func deleteImage() {
        objectDetectionImageView.image = UIImage(systemName: "externaldrive.badge.xmark")?.withRenderingMode(.alwaysOriginal)
        resetTableView()
        checkButton.isHidden = true
        sizeValueLabel.text = "0 KB"
    }
    
    private func resetTableView() {
        DispatchQueue.main.async {
            self.objectDetectionData = []
            self.mainTableView.reloadData()
        }
    }
    
    @IBAction func didTapSelectImageButton(_ sender: UIButton) {
        let imageSelectionAlertController = UIAlertController(title: "Select Image From", message: "Plase select options to fetch image", preferredStyle: .actionSheet)
        imageSelectionAlertController.addAction(
            UIAlertAction(
                title: "Select From Media",
                style: UIAlertAction.Style.default,
                handler: { _ in
                    let imagePickerVC = UIImagePickerController()
                    imagePickerVC.sourceType = .photoLibrary
                    imagePickerVC.delegate = self
                    imagePickerVC.allowsEditing = true
                    self.present(imagePickerVC, animated: true)
                }
            ))
        imageSelectionAlertController.addAction(
            UIAlertAction(
                title: "Select From Photo",
                style: UIAlertAction.Style.default,
                handler: { _ in
                    let cameraPickerVC = UIImagePickerController()
                    cameraPickerVC.sourceType = .camera
                    cameraPickerVC.allowsEditing = true
                    cameraPickerVC.delegate = self
                    self.present(cameraPickerVC, animated: true)
                }
            ))
        imageSelectionAlertController.addAction(
            UIAlertAction(
                title: "Cancel",
                style: UIAlertAction.Style.destructive
            ))
        self.present(imageSelectionAlertController, animated: true, completion: nil)

    }
    
    @IBAction func didTapCheckButton(_ sender: UIButton) {
        viewModel.callObjectDetectionApi(objectImage: objectDetectionImageView.image!)
    }
    
}

extension ObjectDetectionViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objectDetectionData.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(for: indexPath, cellType: ObjectDetectionTableViewCell.self)
        cell.setUpValues(data: objectDetectionData[indexPath.row])
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 45
    }

}

extension ObjectDetectionViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerEditedImage")] as? UIImage {
            objectDetectionImageView.image = image
            let imgData = NSData(data: image.jpegData(compressionQuality: 1)!)
            let imageSize: Int = imgData.count
            let imageSizeKB = Double(imageSize) / 1000.0
            sizeValueLabel.text = "\(round(imageSizeKB)) KB"
            checkButton.isHidden = false
            resetTableView()
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
}
