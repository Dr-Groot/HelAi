//
//  ObjectDetectionTableViewCell.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 25/08/23.
//

import UIKit
import Reusable

class ObjectDetectionTableViewCell: UITableViewCell, NibReusable {
    
    @IBOutlet var objectLabel: UILabel!
    @IBOutlet var confidenceLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setUpValues(data: ObjectDetectionModel) {
        objectLabel.text = data.label?.uppercased()
        var confidence = Double(data.confidence ?? "0")
        confidence = (confidence ?? 0) * 100
        confidenceLabel.text = "\(round(confidence ?? 0))%"
    }
}
