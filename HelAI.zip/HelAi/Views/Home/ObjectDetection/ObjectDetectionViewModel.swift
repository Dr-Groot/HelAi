//
//  ObjectDetectionViewModel.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 23/08/23.
//

import Foundation
import UIKit
import Combine

class ObjectDetectionViewModel {
    
    var observers: Set<AnyCancellable> = []
    var objectDetectionObserver = PassthroughSubject<ObjectDetectionData, Never>()
    var objectDetectionApiLoadingObserver = PassthroughSubject<Bool, Never>()
    
    func callObjectDetectionApi(objectImage: UIImage) {
        self.objectDetectionApiLoadingObserver.send(true)
        MoyaServiceProvider.homeService.requestPublisher(.objectDetection(image: objectImage))
            .sink(receiveCompletion: { Completion in
                switch Completion {
                case .finished:
                    print("Success: OBJECT DETECTION API")
                case .failure(let error):
                    print("Error: \(error)")
                }
            }, receiveValue: {response in
                do {
                    let objectDetectionData = try JSONDecoder().decode(ObjectDetectionData.self, from: response.data)
                    self.objectDetectionObserver.send(objectDetectionData)
                    self.objectDetectionApiLoadingObserver.send(false)
                } catch {
                    print("Error: Decoding Data Object Detection API")
                    self.objectDetectionApiLoadingObserver.send(false)
                }
            }).store(in: &observers)
    }
}
