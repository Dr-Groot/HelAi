//
//  TextSimilarityViewModel.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 30/08/23.
//

import Foundation
import Combine

class TextSimilarityViewModel {
    var observers: Set<AnyCancellable> = []
    var textSimilaritydata = PassthroughSubject<TextSimilarityModel, Never>()
    var textSimilarityDataLoadingObserver = PassthroughSubject<Bool, Never>()
    
    func getTextSimilariyData(text1: String, text2: String) {
        textSimilarityDataLoadingObserver.send(true)
        MoyaServiceProvider.homeService.requestPublisher(.textSimilarity(text1: text1, text2: text2))
            .sink(receiveCompletion: { Completion in
                switch Completion {
                case .finished:
                    print("Success: TEXT SIMILARITY Api called")
                case .failure(let error):
                    print("Error: \(error)")
                }
            }, receiveValue: {response in
                do {
                    let textSimilarityData = try JSONDecoder().decode(TextSimilarityModel.self, from: response.data)
                    self.textSimilaritydata.send(textSimilarityData)
                    self.textSimilarityDataLoadingObserver.send(false)
                } catch {
                    print("Error Text Similarity Response")
                    self.textSimilarityDataLoadingObserver.send(false)
                }
            }).store(in: &observers)
    }
}
