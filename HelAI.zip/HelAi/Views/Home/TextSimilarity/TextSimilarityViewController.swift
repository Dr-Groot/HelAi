//
//  TextSimilarityViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 25/08/23.
//

import UIKit
import Combine

class TextSimilarityViewController: UIViewController {
    
    @IBOutlet var textSimilarityTextField: UITextField!
    @IBOutlet var text1TextView: UITextView!
    @IBOutlet var text2TextView: UITextView!
    @IBOutlet var checkSimilarityUIButton: UIButton!
    @IBOutlet var textSimilarityValueLabel: UILabel!
    
    var observers: Set<AnyCancellable> = []
    var selectedTextView = 1
    var viewModel = TextSimilarityViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configTheme()
        configDependency()
        keyboardHandler()
        setUpGestureRecognizer()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.title = "TEXT SIMILARITY"
    }

    private func configTheme() {
        self.navigationItem.title = "TEXT SIMILARITY"
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "chevron.backward")?.withTintColor(.white, renderingMode: .alwaysOriginal),style: .plain, target: self, action: #selector(dismissVC))
        
        self.textSimilarityTextField.attributedPlaceholder = NSAttributedString(
            string: "Enter Text here ...",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
        
        checkSimilarityUIButton.layer.borderWidth = 2
        checkSimilarityUIButton.layer.borderColor = UIColor.white.cgColor
        checkSimilarityUIButton.layer.cornerRadius = checkSimilarityUIButton.frame.height / 2
        
        text1TextView.layer.borderWidth = 2
        text2TextView.layer.borderWidth = 2
        self.textSimilarityValueLabel.text = "0.0%"
        
        self.setTextView()
    }
    
    private func configDependency() {
        textSimilarityTextField.delegate = self
        let loadingSB = UIStoryboard(name: "LoadingScreen", bundle: .main)
        let loadingScreenVC = loadingSB.instantiateViewController(withIdentifier: "LoadingVC") as! LoadingViewController
        
        viewModel.textSimilarityDataLoadingObserver
            .sink(receiveValue: {value in
                if (value) {
//                LOADING
                    loadingScreenVC.modalPresentationStyle = .overFullScreen
                    self.present(loadingScreenVC, animated: true)
                } else {
//                LOADED
                    loadingScreenVC.popOver()
                }
            }).store(in: &observers)
    
        viewModel.textSimilaritydata
            .sink(receiveValue: {value in
                self.textSimilarityValueLabel.text = "\(round((value.similarity ?? 0.0) * 100))%"
            }).store(in: &observers)
        
    }
    
    private func setUpGestureRecognizer() {
        let gestureRecognizerText1 = UITapGestureRecognizer(target: self, action: #selector(gestureSelectorText1))
        let gestureRecognizerText2 = UITapGestureRecognizer(target: self, action: #selector(gestureSelectorText2))
        gestureRecognizerText1.numberOfTapsRequired = 1
        gestureRecognizerText1.numberOfTouchesRequired = 1
        gestureRecognizerText2.numberOfTapsRequired = 1
        gestureRecognizerText2.numberOfTouchesRequired = 1
        self.text1TextView.addGestureRecognizer(gestureRecognizerText1)
        self.text2TextView.addGestureRecognizer(gestureRecognizerText2)
        self.text1TextView.isUserInteractionEnabled = true
        self.text2TextView.isUserInteractionEnabled = true
    }
    
    private func setTextView() {
        if selectedTextView == 1 {
            text1TextView.layer.borderColor = UIColor.systemRed.cgColor
            text2TextView.layer.borderColor = UIColor.white.cgColor
            textSimilarityTextField.text = text1TextView.text
        } else {
            text1TextView.layer.borderColor = UIColor.white.cgColor
            text2TextView.layer.borderColor = UIColor.systemRed.cgColor
            textSimilarityTextField.text = text2TextView.text
        }
    }
    
    @objc private func gestureSelectorText1() {
        self.selectedTextView = 1
        self.setTextView()
    }
    
    @objc private func gestureSelectorText2() {
        self.selectedTextView = 2
        self.setTextView()
    }
    
    @objc private func dismissVC() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func didTapCheckSimilarityButton(_ sender: UIButton) {
        viewModel.getTextSimilariyData(text1: text1TextView.text, text2: text2TextView.text)
    }
    
}

extension TextSimilarityViewController: UITextFieldDelegate {
    func textField(_ textField: UITextField,
                   shouldChangeCharactersIn range: NSRange,
                   replacementString string: String) -> Bool {
        if self.selectedTextView == 1 {
            self.text1TextView.text = self.textSimilarityTextField.text
        } else {
            self.text2TextView.text = self.textSimilarityTextField.text
        }
        let range1 = NSMakeRange(text1TextView.text.count - 1, 0)
        text1TextView.scrollRangeToVisible(range1)
        
        let range2 = NSMakeRange(text2TextView.text.count - 1, 0)
        text2TextView.scrollRangeToVisible(range2)

        return true
    }
}

extension TextSimilarityViewController {
    private func keyboardHandler() {
        let tap = UITapGestureRecognizer(
            target: self,
            action: #selector(UIInputViewController.dismissKeyboard)
        )
        view.addGestureRecognizer(tap)

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillShow),
            name: UIResponder.keyboardWillShowNotification,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillHide),
            name: UIResponder.keyboardWillHideNotification,
            object: nil
        )
    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    @objc func keyboardWillShow(notification: NSNotification) {
        if ((notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey]
             as? NSValue)?.cgRectValue) != nil {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= 0
            }
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
}
