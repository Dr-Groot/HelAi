//
//  HomeViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 17/08/23.
//

import UIKit
import Lottie

class HomeViewController: UIViewController {
        
    @IBOutlet var imageToTextButton: UIButton!
    @IBOutlet var objectDetectionButton: UIButton!
    @IBOutlet var sentimentAnalysisButton: UIButton!
    @IBOutlet var textSimilarityButton: UIButton!
    @IBOutlet var aiTagLineTextView: UITextView!
    @IBOutlet var helAiHomeLottieAnimation: LottieAnimationView!
    
    let myText = "The term AI, coined in the 1950s, refers to the simulation of human intelligence by machines. It covers an ever-changing set of capabilities as new technologies are developed. Technologies that come under the umbrella of AI include machine learning and deep learning.Artificial intelligence is the intelligence of machines or software, as opposed to the intelligence of human beings or animals.".components(separatedBy: " ")
    var myCounter = 0
    var timer:Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
        configDependency()
        setAnimation()
        fireTimer()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.title = "HOME"
    }
    
    private func configTheme() {
        self.navigationItem.title = "HOME"

        imageToTextButton.layer.borderWidth = 2.0
        imageToTextButton.layer.borderColor = UIColor.systemRed.cgColor

        objectDetectionButton.layer.borderWidth = 2.0
        objectDetectionButton.layer.borderColor = UIColor.systemRed.cgColor
        
        sentimentAnalysisButton.layer.borderWidth = 2.0
        sentimentAnalysisButton.layer.borderColor = UIColor.systemRed.cgColor

        textSimilarityButton.layer.borderWidth = 2.0
        textSimilarityButton.layer.borderColor = UIColor.systemRed.cgColor
        
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background2")!)

    }

    private func configDependency() {}
    
    private func setAnimation() {
//        helAiHomeLottieAnimation.backgroundColor = .
        helAiHomeLottieAnimation.contentMode = .scaleAspectFill
        helAiHomeLottieAnimation.loopMode = .loop
        helAiHomeLottieAnimation.animationSpeed = 0.5
        helAiHomeLottieAnimation.play()
    }
    
    private func fireTimer(){
        timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(self.typeLetter), userInfo: nil, repeats: true)
    }
    
    @objc func typeLetter(){
            if myCounter < myText.count {
                aiTagLineTextView.text = aiTagLineTextView.text! + String(myText[myCounter]) + " "
                let randomInterval = Double((arc4random_uniform(8)+1))/10
                timer?.invalidate()
                timer = Timer.scheduledTimer(timeInterval: randomInterval, target: self, selector: #selector(self.typeLetter), userInfo: nil, repeats: false)
            } else {
                timer?.invalidate()
            }
        myCounter = myCounter + 1
    }
    
    @IBAction func didTapImageToTextButton(_ sender: UIButton) {
        let imageToTextSB = UIStoryboard(name: "ImageToTextScreen", bundle: .main)
        let imageToTextVC = imageToTextSB.instantiateViewController(withIdentifier: "ImageToTextVC") as! ImageToTextViewController
        imageToTextVC.modalPresentationStyle = .fullScreen
        self.navigationController?.pushViewController(imageToTextVC, animated: true)
    }
    
    @IBAction func didTapObjectDetectionButton(_ sender: UIButton) {
        let objectDetectionSB = UIStoryboard(name: "ObjectDetectionScreen", bundle: .main)
        let objectDetectionVC = objectDetectionSB.instantiateViewController(identifier: "ObjectDetectionVC") as! ObjectDetectionViewController
        objectDetectionVC.modalPresentationStyle = .fullScreen
        self.navigationController?.pushViewController(objectDetectionVC, animated: true)
    }
    
    @IBAction func didTapSentimentAnalysisButton(_ sender: UIButton) {
        let sentimentAnalysisSB = UIStoryboard(name: "SentimentAnalysisScreen", bundle: .main)
        let sentimentAnalysisVC = sentimentAnalysisSB.instantiateViewController(identifier: "SentimentAnalysisVC") as! SentimentAnalysisViewController
        sentimentAnalysisVC.modalPresentationStyle = .fullScreen
        self.navigationController?.pushViewController(sentimentAnalysisVC, animated: true)
    }
    
    @IBAction func didTapTextSimilarityButton(_ sender: UIButton) {
        let textSimilaritySB = UIStoryboard(name: "TextSimilarityScreen", bundle: .main)
        let textSimilarityVC = textSimilaritySB.instantiateViewController(identifier: "TextSimilarityVC") as! TextSimilarityViewController
        textSimilarityVC.modalPresentationStyle = .fullScreen
        self.navigationController?.pushViewController(textSimilarityVC, animated: true)
    }
    
}
