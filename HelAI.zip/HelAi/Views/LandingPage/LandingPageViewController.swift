//
//  LandingPageViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 01/09/23.
//

import UIKit

class LandingPageViewController: UIViewController {
    
    @IBOutlet var loginButton: UIButton!
    @IBOutlet var signUpButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
    }
    
    private func configTheme() {
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background2")!)

        loginButton.layer.borderWidth = 2
        loginButton.layer.borderColor = UIColor.white.cgColor
        loginButton.layer.cornerRadius = loginButton.frame.height / 2

        signUpButton.layer.borderWidth = 2
        signUpButton.layer.borderColor = UIColor.white.cgColor
        signUpButton.layer.cornerRadius = signUpButton.frame.height / 2
    }
    
    @IBAction func didTapLoginButton(_ sender: UIButton) {
        let LoginSB = UIStoryboard(name: "LogInScreen", bundle: .main)
        let loginVC = LoginSB.instantiateViewController(withIdentifier: "LoginVC") as! LogInViewController
        loginVC.modalPresentationStyle = .fullScreen
        self.present(loginVC, animated: true)
    }
    
    @IBAction func didTapSignUpButton(_ sender: UIButton) {
        let SignUpSB = UIStoryboard(name: "SignUpScreen", bundle: .main)
        let SignUpVC = SignUpSB.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpViewController
        SignUpVC.modalPresentationStyle = .fullScreen
        self.present(SignUpVC, animated: true)
    }

}
