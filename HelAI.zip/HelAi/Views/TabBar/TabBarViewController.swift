//
//  TabBarViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 17/08/23.
//

import UIKit

class TabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
