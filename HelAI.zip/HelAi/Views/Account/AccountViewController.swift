//
//  AccountViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 17/08/23.
//

import UIKit
import Firebase

class AccountViewController: UIViewController {

    @IBOutlet var signOutButton: UIButton!
    @IBOutlet var userInfoLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
    }

    private func configTheme() {
        self.navigationItem.title = "ACCOUNT"
        
        signOutButton.layer.borderWidth = 2
        signOutButton.layer.borderColor = UIColor.white.cgColor
        signOutButton.layer.cornerRadius = signOutButton.frame.height / 2
        
        userInfoLabel.text = FirebaseAuth.Auth.auth().currentUser?.email ?? "No user found !"
    }

    @IBAction func didTapSignOutButton(_ sender: UIButton) {
        FirebaseHelper.shared.logOut()
        let LandingPageSB = UIStoryboard(name: "LandingPageScreen", bundle: .main)
        let landingPageVC = LandingPageSB.instantiateViewController(withIdentifier: "LandingPageVC") as! LandingPageViewController
        landingPageVC.modalPresentationStyle = .fullScreen
        self.present(landingPageVC, animated: true)
    }
    
}
