//
//  LoadingViewController.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 23/08/23.
//

import UIKit
import Lottie

class LoadingViewController: UIViewController {
    
    @IBOutlet var loadingAnimationVIew: LottieAnimationView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadingAnimationVIew.backgroundColor = .clear
        loadingAnimationVIew.contentMode = .scaleAspectFit
        loadingAnimationVIew.loopMode = .loop
        loadingAnimationVIew.animationSpeed = 0.5
        loadingAnimationVIew.play()
    }
    
    func popOver() {
        self.dismiss(animated: true)
    }

}
