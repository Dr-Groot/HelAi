//
//  MoyaServiceProvider.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 22/08/23.
//

import Foundation
import Moya

class MoyaServiceProvider {
    
    static let homeService = MoyaProvider<HomeServices>(
        session: DefaultAlamofireManager.sharedManager,
        plugins: MoyaHelper.shared.getPlugins()
    )
}
