//
//  AppInfo.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 22/08/23.
//

import Foundation

class AppInfo {
    static let shared = AppInfo()
    
    private init() {}
    
    lazy var buildNumber: Int = {
        guard let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String,
            let buildNumber = Int(build) else {
            return 0
        }
        return buildNumber
    }()

    lazy var buildVersion: String = {
        guard let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String else {
            return ""
        }
        return version
    }()

    lazy var displayName: String = {
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String ??
            Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String ?? ""
    }()

    lazy var bundleID: String = {
        return Bundle.main.bundleIdentifier ?? ""
    }()

    lazy var apiBaseUrl: String = {
        return Constants.baseUrl
    }()
    
    lazy var apiKey: String = {
        return Constants.apiKey
    }()

}
