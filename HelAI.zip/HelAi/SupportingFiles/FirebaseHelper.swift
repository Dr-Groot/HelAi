//
//  LogInViewModel.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 01/09/23.
//

import Foundation
import Firebase
import FirebaseAuth
import FirebaseCore
import Combine

class FirebaseHelper {
    
    static let shared = FirebaseHelper()
    
    var isLogedInObserver = PassthroughSubject<String, Never>()
    var isAccountCreated = PassthroughSubject<Bool, Never>()
    
    func logIn(email: String, password: String) {
        var userEmail: String = email
        var userPassword :String = password
        FirebaseAuth.Auth.auth().signIn(withEmail: userEmail, password: userPassword, completion: { result, error in
            self.isLogedInObserver.send(result?.user.email ?? "")
        })
    }
    
    func accountCreate(email: String, password: String) {
        FirebaseAuth.Auth.auth().createUser(withEmail: email, password: password, completion: {result, error in
            result != nil
            ? self.isAccountCreated.send(true)
            : self.isAccountCreated.send(false)
        })
    }
    
    
    func logOut() {
        try! FirebaseAuth.Auth.auth().signOut()
    }
}
