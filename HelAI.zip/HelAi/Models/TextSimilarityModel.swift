//
//  TextSimilarityModel.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 30/08/23.
//

import Foundation

struct TextSimilarityModel: Codable {
    let similarity: Double?
    
    init(similarity: Double? = nil) {
        self.similarity = similarity
    }
    
    enum CodingKeys: String, CodingKey {
        case similarity
    }
}
