//
//  ObjectDetectionModel.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 24/08/23.
//

import Foundation

struct ObjectDetectionModel: Codable {
    let label: String?
    let confidence: String?
    let boundingBox: ObjectDetectionBoundingBox?
    
    init(label: String? = nil, confidence: String? = nil, boundingBox: ObjectDetectionBoundingBox? = nil) {
        self.label = label
        self.confidence = confidence
        self.boundingBox = boundingBox
    }
    
    enum CodingKeys: String, CodingKey {
        case label
        case confidence
        case boundingBox = "bounding_box"
    }

}

struct ObjectDetectionBoundingBox: Codable {
    let x1: String?
    let x2: String?
    let x3: String?
    let x4: String?
    
    init(x1: String? = nil, x2: String? = nil, x3: String? = nil, x4: String? = nil) {
        self.x1 = x1
        self.x2 = x2
        self.x3 = x3
        self.x4 = x4
    }
    
    enum CodingKeys: String, CodingKey {
        case x1
        case x2
        case x3
        case x4
    }
}
typealias ObjectDetectionData = [ObjectDetectionModel]
