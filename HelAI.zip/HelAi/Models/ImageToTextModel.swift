//
//  ImageToTextModel.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 22/08/23.
//

import Foundation
import Moya

struct ImageToTextModel: Codable {
    let text: String?
    let boundingBox: BoundingBox?

    init(text: String? = nil, boundingBox: BoundingBox? = nil) {
        self.text = text
        self.boundingBox = boundingBox
    }

    enum CodingKeys: String, CodingKey {
        case text
        case boundingBox = "bounding_box"
    }
}

struct BoundingBox: Codable {
    let x1: Int?
    let x2: Int?
    let x3: Int?
    let x4: Int?

    init(x1: Int? = nil, x2: Int? = nil, x3: Int? = nil, x4: Int? = nil) {
        self.x1 = x1
        self.x2 = x2
        self.x3 = x3
        self.x4 = x4
    }

    enum CodingKeys: String, CodingKey {
        case x1
        case x2
        case x3
        case x4
    }
}

typealias ImageToTextModelData = [ImageToTextModel]
