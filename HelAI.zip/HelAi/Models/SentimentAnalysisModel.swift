//
//  SentimentAnalysisModel.swift
//  HelAi
//
//  Created by Aman Pratap Singh on 25/08/23.
//

import Foundation

struct SentimentAnalysisModel: Codable {
    let score: Double?
    let text: String?
    let sentiment: String?
    
    init(score: Double?, text: String?, sentiment: String?) {
        self.score = score
        self.text = text
        self.sentiment = sentiment
    }
    
    enum CodingKeys: String, CodingKey {
        case score
        case text
        case sentiment
    }
}

typealias SentimentAnalysisData = SentimentAnalysisModel
